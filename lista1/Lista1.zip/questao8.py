n1 = input("Digite a primeira nota: ")
n2 = input("Digite a segunda nota: ")
n3 = input("Digite a terceira nota: ")
n4 = input("Digite a quarta nota: ")
media = (float(n1) + float(n2) + float(n3) + float(n4)) / 4
print("A média é: ", media)