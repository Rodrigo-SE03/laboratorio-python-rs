tempF = input("Digite a temperatura em Fahrenheit: ")
tempC = (float(tempF) - 32) * 5/9
print("A temperatura em Celsius é: ", tempC)