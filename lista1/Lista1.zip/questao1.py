num1 = input("Digite o primeiro número: ")
num2 = input("Digite o segundo número: ")
print("A soma é: ", float(num1) + float(num2))