altura = input("Digite a altura: ")
largura = input("Digite a largura: ")
area = float(altura) * float(largura)
print("A área é: ", area)