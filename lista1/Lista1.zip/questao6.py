dias = input("Digite a quantidade de dias: ")
segundos = int(dias) * 24 * 60 * 60
print("A quantidade de segundos é: ", segundos)