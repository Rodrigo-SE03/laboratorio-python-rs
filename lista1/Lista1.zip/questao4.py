tempC = input("Digite a temperatura em Celsius: ")
tempF = (float(tempC) * 1.8) + 32
print("A temperatura em Fahrenheit é: ", tempF)