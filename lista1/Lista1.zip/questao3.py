raio = input("Digite o raio: ")
    
area = 3.14 * float(raio) ** 2
print("A área é: ", area)