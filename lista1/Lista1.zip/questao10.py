peso = input("Digite o peso: ")
altura = input("Digite a altura: ")
imc = float(peso)/(float(altura)**2)
print("O IMC é: ", imc)