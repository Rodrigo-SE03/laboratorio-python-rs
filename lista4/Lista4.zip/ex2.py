def conv(dol):
    return dol * 5.46

dol = float(input("Digite o valor em dólares: "))
print(f"O valor em reais é: {conv(dol)}")