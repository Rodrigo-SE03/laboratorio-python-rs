def soma_5(a,b,c,d,e):
    return a+b+c+d+e

soma = soma_5(1,2,3,4,5)
print(soma)