lim_i = int(input("Digite o limite inferior: "))
lim_s = int(input("Digite o limite superior: "))

for i in range(lim_i, lim_s):
    print(i)