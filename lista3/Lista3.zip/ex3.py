num = int(input("Digite um número: "))

fat = 1
for i in range(num):
    fat*=i+1

print(fat)