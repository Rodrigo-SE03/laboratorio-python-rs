num1 = float(input("Digite um número: "))
num2 = float(input("Digite outro número: "))

nums = [num1,num2]
print(max(nums))