nums = []
for i in range(3):
    nums.append(float(input("Digite um número: ")))

print("Maior número: ",max(nums))
print("Menor número: ",min(nums))